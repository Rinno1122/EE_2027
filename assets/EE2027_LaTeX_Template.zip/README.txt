===============================================================================
ENERGY AND THE ENVIRONMENT 2027 — OFFICIAL LATEX MANUSCRIPT TEMPLATE
26th International Scientific & Professional Congress (50th Anniversary, 1977-2027)
Rijeka, Croatia | 22 October 2027
Croatian Solar Energy Association (HSSE) & RITEH, University of Rijeka
===============================================================================

PACKAGE CONTENTS
----------------
- main.tex                     : Main manuscript file (start editing here)
- ee2027.cls                   : Official Congress LaTeX document class
- references.bib               : Example BibTeX file (Elsevier numbered style)
- figures/vitruvian_emblem.png : Official Vitruvian Man Congress emblem (header & Fig. 1)
- figures/panel_a.png          : Sample figure panel (a)
- figures/panel_b.png          : Sample figure panel (b)
- README.txt                   : This guide

FORMATTING SUMMARY
------------------
- Paper size & margins : A4 (210 mm x 297 mm), 2.5 cm left/right margins, no line numbers
- Font                 : Times New Roman (newtxtext/newtxmath on pdfLaTeX; Times New Roman / TeX Gyre Termes on XeLaTeX/LuaLaTeX)
- Main text            : 11 pt, 1.25 line spacing
- Affiliations & Refs  : 10 pt, 1.15 line spacing
- Recommended length   : Between 4 and 6 pages of text (max 2 articles per author)
- References           : Elsevier numbered style with titles (elsarticle-num)

HOW TO COMPILE
--------------
1. Overleaf (Recommended):
   - Upload EE2027_LaTeX_Template.zip via "New Project -> Upload Project".
   - Click "Recompile" (default pdfLaTeX compiler works out of the box).

2. Local TeX Live / MiKTeX:
   pdflatex main.tex
   bibtex main
   pdflatex main.tex
   pdflatex main.tex

   (You may also use latexmk -pdf main.tex, xelatex, or lualatex.)

Note: The BibTeX style `elsarticle-num.bst` is included by default in Overleaf,
TeX Live, and MiKTeX (package `elsarticle`).

CONTACT
-------
Congress Secretariat: ee2027@riteh.hr
Official Portal     : https://rinno1122.github.io/EE_2027/
