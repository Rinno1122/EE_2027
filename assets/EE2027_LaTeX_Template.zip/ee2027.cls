% =============================================================================
% ee2027.cls — Official LaTeX Manuscript Class
% 26th International Scientific & Professional Congress
% Energy and the Environment 2027 (50th Anniversary, 1977--2027)
% Rijeka, Croatia | 22 October 2027
% Croatian Solar Energy Association (HSSE) & RITEH, University of Rijeka
% =============================================================================
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{ee2027}[2026/11/26 v1.0 Energy and the Environment 2027 Proceedings Class]

\LoadClass[11pt,a4paper,oneside]{article}

% -----------------------------------------------------------------------------
% Page Geometry (A4, 2.5 cm margins, NO line numbers)
% -----------------------------------------------------------------------------
\RequirePackage[
  a4paper,
  left=2.5cm,
  right=2.5cm,
  top=3.0cm,
  bottom=2.3cm,
  headheight=50pt,
  headsep=12pt,
  footskip=26pt
]{geometry}

% -----------------------------------------------------------------------------
% Fonts: Times New Roman across pdfLaTeX, XeLaTeX, and LuaLaTeX
% -----------------------------------------------------------------------------
\RequirePackage{amsmath}
\RequirePackage{iftex}
\ifPDFTeX
  \RequirePackage[T1]{fontenc}
  \RequirePackage[utf8]{inputenc}
  \IfFileExists{newtxtext.sty}{%
    \RequirePackage{newtxtext}%
    \RequirePackage{newtxmath}%
  }{%
    \RequirePackage{mathptmx}%
  }
\else
  \RequirePackage{fontspec}
  \IfFontExistsTF{Times New Roman}{%
    \setmainfont{Times New Roman}%
  }{%
    \setmainfont{TeX Gyre Termes}%
  }
\fi
\RequirePackage{microtype}

% -----------------------------------------------------------------------------
% Line Spacing & Paragraph Layout
% Main text: 11 pt Times New Roman, 1.25 line spacing
% Affiliations & References: 10 pt Times New Roman, 1.15 line spacing
% -----------------------------------------------------------------------------
\RequirePackage{setspace}
\setstretch{1.25}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}

% -----------------------------------------------------------------------------
% Colors, Graphics, Tables, Lists, Captions
% -----------------------------------------------------------------------------
\RequirePackage[table]{xcolor}
\definecolor{eeNavy}{HTML}{0B2545}
\definecolor{eeSolar}{HTML}{B45309}
\definecolor{eeAmber}{HTML}{D97706}
\definecolor{eeMuted}{HTML}{4B5563}
\definecolor{eeRowShade}{HTML}{F1F5F9}
\definecolor{eeRuleLight}{HTML}{CBD5E1}

\RequirePackage{graphicx}
\RequirePackage{booktabs}
\RequirePackage{array}
\RequirePackage{tabularx}
\RequirePackage{enumitem}
\RequirePackage{etoolbox}
\RequirePackage{lastpage}
\RequirePackage{fancyhdr}
\RequirePackage{titlesec}
\RequirePackage[font={small},labelfont={bf,color=eeNavy},labelsep=period,skip=6pt]{caption}
\RequirePackage{subcaption}

\setlist[itemize]{leftmargin=1.4em,itemsep=2pt,topsep=3pt,parsep=0pt}
\setlist[enumerate]{leftmargin=1.6em,itemsep=2pt,topsep=3pt,parsep=0pt}

% -----------------------------------------------------------------------------
% Section Headings (Times New Roman, Navy accent, 1.25 line spacing)
% -----------------------------------------------------------------------------
\titleformat{\section}
  {\normalfont\fontsize{12.5}{15.5}\selectfont\bfseries\color{eeNavy}}
  {\thesection.}{0.5em}{}
\titlespacing*{\section}{0pt}{12pt}{4pt}

\titleformat{\subsection}
  {\normalfont\fontsize{11.5}{14.5}\selectfont\bfseries\color{eeNavy}}
  {\thesubsection.}{0.5em}{}
\titlespacing*{\subsection}{0pt}{10pt}{3pt}

\titleformat{\subsubsection}
  {\normalfont\fontsize{11}{13.75}\selectfont\itshape\color{black}}
  {\thesubsubsection.}{0.5em}{}
\titlespacing*{\subsubsection}{0pt}{8pt}{2pt}

% -----------------------------------------------------------------------------
% Headers & Footers (Vitruvian Man Emblem + Congress Banner)
% -----------------------------------------------------------------------------
\newcommand{\ee@emblem}{figures/vitruvian_emblem.png}

% Running pages (Pages 2+)
\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0pt}
\renewcommand{\footrulewidth}{0pt}

\fancyhead[L]{%
  \parbox[b]{\textwidth}{%
    \begin{minipage}[c]{1.15cm}%
      \includegraphics[height=0.88cm]{\ee@emblem}%
    \end{minipage}\hfill
    \begin{minipage}[c]{\dimexpr\textwidth-1.35cm\relax}%
      \raggedleft
      {\fontsize{8.5}{10}\selectfont\itshape\color{eeMuted}%
        Energy and the Environment 2027 \enspace|\enspace 26th International Congress (50th Anniversary) --- Rijeka, Croatia}%
    \end{minipage}\\[3pt]
    \noindent{\color{eeAmber}\rule{1.2cm}{0.8pt}}{\color{eeNavy}\rule{\dimexpr\textwidth-1.2cm\relax}{0.8pt}}%
  }%
}

\fancyfoot[L]{%
  \parbox[t]{\textwidth}{%
    \noindent{\color{eeRuleLight}\rule{\textwidth}{0.5pt}}\\[2pt]
    {\fontsize{8.5}{10}\selectfont\itshape\color{eeMuted}%
      Proceedings of the 26th International Congress Energy and the Environment 2027 (ISBN)}%
    \hfill
    {\fontsize{8.5}{10}\selectfont\color{eeMuted}%
      Page \thepage\ of \pageref{LastPage}}%
  }%
}

% First Page Header & Footer
\fancypagestyle{firstpage}{%
  \fancyhf{}%
  \renewcommand{\headrulewidth}{0pt}%
  \renewcommand{\footrulewidth}{0pt}%
  \fancyhead[L]{%
    \parbox[b]{\textwidth}{%
      \begin{minipage}[c]{1.85cm}%
        \includegraphics[height=1.55cm]{\ee@emblem}%
      \end{minipage}\hfill
      \begin{minipage}[c]{\dimexpr\textwidth-2.05cm\relax}%
        \raggedleft
        {\fontsize{11}{13}\selectfont\bfseries\color{eeNavy} ENERGY AND THE ENVIRONMENT 2027}\\[2pt]
        {\fontsize{8.5}{10}\selectfont\bfseries\itshape\color{eeSolar} 26th International Scientific \& Professional Congress $\bullet$ 50th Anniversary (1977--2027)}\\[2pt]
        {\fontsize{8}{9.5}\selectfont\color{eeMuted} Rijeka, Croatia $\bullet$ 22 October 2027 \enspace|\enspace Croatian Solar Energy Association (HSSE) \& RITEH, University of Rijeka}%
      \end{minipage}\\[4pt]
      \noindent{\color{eeAmber}\rule{1.9cm}{1.4pt}}{\color{eeNavy}\rule{\dimexpr\textwidth-1.9cm\relax}{1.4pt}}%
    }%
  }%
  \fancyfoot[L]{%
    \parbox[t]{\textwidth}{%
      \noindent{\color{eeRuleLight}\rule{\textwidth}{0.5pt}}\\[2pt]
      {\fontsize{8.5}{10}\selectfont\itshape\color{eeMuted}%
        Proceedings of the 26th International Congress Energy and the Environment 2027 (ISBN)}%
      \hfill
      {\fontsize{8.5}{10}\selectfont\color{eeMuted}%
        Page \thepage\ of \pageref{LastPage}}%
    }%
  }%
}

% -----------------------------------------------------------------------------
% Front Matter Macros (Title, Authors, 10pt/1.15 Affiliations, Abstract, Keywords)
% -----------------------------------------------------------------------------
\newcommand{\ee@papertype}{Proceeding Paper (Original Research / Review / Professional Paper)}
\newcommand{\papertype}[1]{\renewcommand{\ee@papertype}{#1}}

\newcommand{\ee@authors}{}
\renewcommand{\author}[1]{\renewcommand{\ee@authors}{#1}}

\newcommand{\ee@affiliations}{}
\newcommand{\affiliations}[1]{\renewcommand{\ee@affiliations}{#1}}

\newcommand{\ee@abstract}{}
\newcommand{\eeabstract}[1]{\renewcommand{\ee@abstract}{#1}}

\newcommand{\ee@keywords}{}
\newcommand{\keywords}[1]{\renewcommand{\ee@keywords}{#1}}

\newcommand{\affiliation}[2]{%
  \par\noindent\textsuperscript{\textbf{\color{eeNavy}#1}}\hspace{0.25em}{\color{eeMuted}#2}%
}

\newcommand{\correspondence}[1]{%
  \par\noindent\textsuperscript{\textbf{\color{eeNavy}*}}\hspace{0.25em}{\color{eeMuted}Correspondence: #1}%
}

\newcommand{\congressnote}[1]{%
  \par\noindent\textsuperscript{\textbf{\color{eeNavy}\dag}}\hspace{0.25em}{\itshape\color{eeMuted}#1}%
}

\newcommand{\makefrontmatter}{%
  \thispagestyle{firstpage}%
  \vspace*{2pt}%
  {\noindent\fontsize{9.5}{11.5}\selectfont\itshape\color{eeSolar}\ee@papertype\par}%
  \vspace{2pt}%
  {\noindent\setstretch{1.15}\fontsize{16}{18.5}\selectfont\bfseries\color{eeNavy}\@title\textsuperscript{\fontsize{11}{13}\selectfont\color{eeSolar}\dag}\par}%
  \vspace{4pt}%
  {\noindent\fontsize{11}{13}\selectfont\bfseries\color{black}\ee@authors\par}%
  \vspace{3pt}%
  {%
    \begingroup
    \setstretch{1.15}%
    \fontsize{10}{11.5}\selectfont
    \setlength{\parskip}{2pt}%
    \ee@affiliations\par
    \endgroup
  }%
  \vspace{4pt}%
  \noindent{\color{eeNavy}\rule{\textwidth}{1.0pt}}%
  \vspace{5pt}%
  {%
    \begingroup
    \setstretch{1.15}%
    \fontsize{10}{11.5}\selectfont
    \noindent{\bfseries\color{eeNavy}Abstract: }\ee@abstract\par
    \vspace{4pt}%
    \noindent{\bfseries\color{eeNavy}Keywords: }{\itshape\ee@keywords}\par
    \endgroup
  }%
  \vspace{3pt}%
  \noindent{\color{eeAmber}\rule{\textwidth}{0.8pt}}%
  \vspace{6pt}%
}

% -----------------------------------------------------------------------------
% Back-Matter Declaration Helper (Elsevier Style)
% -----------------------------------------------------------------------------
\newcommand{\declaration}[2]{%
  \begingroup
  \setstretch{1.15}%
  \fontsize{10}{11.5}\selectfont
  \par\vspace{2pt}\noindent{\bfseries\color{eeNavy}#1: }#2\par
  \endgroup
}

% -----------------------------------------------------------------------------
% References — Elsevier Numbered Style (10 pt Times New Roman, 1.15 spacing)
% -----------------------------------------------------------------------------
\RequirePackage[numbers,sort&compress]{natbib}
\renewcommand{\bibnumfmt}[1]{\textbf{\color{eeNavy}[#1]}}
\setlength{\bibsep}{3pt plus 1pt minus 1pt}

\AtBeginEnvironment{thebibliography}{%
  \setstretch{1.15}%
  \fontsize{10}{11.5}\selectfont
}

% -----------------------------------------------------------------------------
% Hyperlinks (loaded last)
% -----------------------------------------------------------------------------
\RequirePackage[
  colorlinks=true,
  linkcolor=eeNavy,
  citecolor=eeNavy,
  urlcolor=eeNavy,
  pdfborder={0 0 0}
]{hyperref}
